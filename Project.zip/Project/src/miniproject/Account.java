package miniproject;

public abstract class Account {  
    abstract double calculateInterest(double amount) throws InvalidAmountException, InvalidYearsException; 
}
