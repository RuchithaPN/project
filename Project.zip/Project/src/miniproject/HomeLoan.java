package miniproject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class HomeLoan extends Account {
	double hlAmount , interestRate,noOfYears;
    Scanner scanner = new Scanner(System.in);
    
    enum Bank      // enum class to declare constant values to interest rate
	{
		SBI(9.5), 
		CANARA(9), 
		ICICI(9.2), 
		UNION(8.5), 
		HDFC(6.75);

		private final double interestRate;

		Bank(double interestRate)
    	{
    	this.interestRate = interestRate ;
     }

		public double getInterestRate() {
     return interestRate ;
   }
	}
	@Override
    	double calculateInterest(double amount) throws InvalidAmountException, InvalidYearsException {
    	this.hlAmount = amount;
    	 if (hlAmount <= 0) {     // exception statement that returns exception if user enters the principle amount lesser than 0.
    	 throw new InvalidAmountException();
    	}
    	 System.out.println("Enter number of years");
        noOfYears = scanner.nextDouble();
    	if (noOfYears > 30) {      // exception statement that returns exception if number of years greater than 30
     throw new InvalidYearsException();
    	}
    	System.out.println("Select the bank");
    	 for (int i = 0; i < Bank.values().length; i++) {
    	System.out.println(i + 1 + ". " + Bank.values()[i].name());
    	}
    	int accountChoice = scanner.nextInt();
    	 if (accountChoice < 1 || accountChoice > Bank.values().length) {
    throw new IllegalArgumentException("Please choose the right bank: " + accountChoice);
    	}
    	 Bank bank = Bank.values()[accountChoice - 1];
    	 double interestAmount = amount * bank.getInterestRate() * noOfYears / 100;    // formula to calculate interest rate
    	
    	// Write output to file with date and time
         DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
         Date date = new Date();
         String dateTime = dateFormat.format(date);
         File file = new File("C:\\Users\\241352\\Java-Workspace\\Project\\output1.txt");

         try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
        	 writer.println("Generated date and time:" +dateTime);
        	 writer.println("------------------------------");
             writer.println("Home Loan");
             writer.println("-------------------------------");
             writer.println("Principle amount: " + amount);
             writer.println("Number of years: " + noOfYears);
             writer.println("Interest amount: " + interestAmount);
             writer.println();
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        return interestAmount;
	}
	
}
