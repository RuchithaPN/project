package miniproject;

public class InvalidYearsException extends Exception{

}
