package miniproject;

public class InvalidAmountException extends Exception {
	

}
