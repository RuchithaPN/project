package miniproject;

import java.util.Date;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class BusinessLoan extends Account {
    double blAmount, interestRate, noOfYears; // declaring variables
    Scanner scanner = new Scanner(System.in);

    @Override
    double calculateInterest(double amount) throws InvalidAmountException, InvalidYearsException {
        this.blAmount = amount; // refers to the instance variable
        if (blAmount <= 0) { // exception statement that returns exception if user enters the principle amount lesser than 0.
            throw new InvalidAmountException();
        }
        System.out.println("Enter number of years");
        noOfYears = scanner.nextDouble();
        if (noOfYears > 5) { // exception statement that returns exception if number of years greater than 5
            throw new InvalidYearsException();
        }

        System.out.println(
                "Select the bank  \n1. SBI \n2. CANARA  \n3. ICICI  \n4. UNION  \n5. HDFC");
        int accountChoice = scanner.nextInt();
        double InterestRate = switch (accountChoice) // switch statement to select the interest for the user selected bank
        {
        case 1 -> 11.20;
        case 2 -> 9.85;
        case 3 -> 10.40;
        case 4 -> 8.20;
        case 5 -> 10;
        default -> throw new IllegalArgumentException(
                "Please choose the right bank: " + accountChoice);

        };

        double interestAmount = amount * InterestRate * noOfYears / 100; // formula to calculate interest amount
     // Write output to file with date and time
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String dateTime = dateFormat.format(date);
        File file = new File("C:\\Users\\241352\\Java-Workspace\\Project\\output1.txt");

        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
        	writer.println("Generated date and time:" +dateTime);
        	writer.println("------------------------------");
            writer.println("Business Loan");
            writer.println("-------------------------------");
            writer.println("Principle amount: " + amount);
            writer.println("Number of years: " + noOfYears);
            writer.println("Bank interest rate: " + InterestRate);
            writer.println("Interest amount: " + interestAmount);
            writer.println();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return interestAmount;
    }
}
