package miniproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class InterestAmountCalculator {
	

	    public void Interest() throws InvalidYearsException, InvalidAmountException {    
		Scanner sc = new Scanner(System.in);
		do {
        System.out.println(" INTEREST CALCULATOR  !!!!!" + "\n1." + " General Interest Calculator" + " \n2." + " Loans Interest Calculator"+ " \n3." +" Show History"+ "\n4." +" Reset"+"\n5."+" Exit ");      		
        int choice = sc.nextInt(); 
        try {
        switch (choice)
        {
        case 1:
            	 System.out.println("SELECT THE OPTIONS " + "\n1." + " Simple Interest Calculator" + " \n2." + " Compound Interest Calculator");
                 int ch = sc.nextInt();
                 switch (ch)
                 {
                     case 1:
                    	 SimpleInterest si = new SimpleInterest();    //creating an object for simpleInterest class
					     System.out.println("Enter the principle amount ");
					     double amount = sc.nextDouble();
					     try    
					     {
					     System.out.println("Interest amount is : Rs " + si.calculateInterest(amount));   //calling the method using object
					     } catch (InvalidAmountException e)
					     {
			                    System.out.println("Exception : Invalid amount!");
			                }
                         break;
                     case 2:
                    	 CompoundInterest ci = new CompoundInterest();  //creating an object for compoundInterest class
					     System.out.println("Enter the principle amount ");
					     double camount = sc.nextDouble();
					     try {
					     System.out.println("Interest amount is : Rs " + ci.calculateInterest(camount));
					     }catch (InvalidAmountException e) 
					     {
			                    System.out.println("Exception : Invalid amount!");
			                }
                         break;
                         
                      default:
                         System.out.println("Wrong choice");
                         break;
               
	                  }
        case 2:
            	  System.out.println("SELECT THE LOAN TYPE" + "\n1." + " Personal Loan Calculator" + " \n2." + " Home Loan Calculator" + " \n3." + " Gold Loan Calculator" + " \n4." + " Agriculture Loan Calculator"+ " \n5." + " Business Loan Calculator"+"\n6."+" Show History"+"\n7."+" Reset" +"\n8." + " Exit");
            	  int op = sc.nextInt();               
                  switch (op)
                  {                
                   case 1:
                    	 PersonalLoan pl=new PersonalLoan();     //creating an object for PersonalLoan class
                    	 System.out.println("Enter the principle amount in Rs ");
					     double plamount = sc.nextDouble();
					     try 
					     {
					     System.out.println("Interest amount is : Rs " + pl.calculateInterest(plamount));
					     }catch (InvalidAmountException e) 
					     {
			                    System.out.println("Exception : Invalid amount!");
			                }
                         break;
                   case 2:
                    	 HomeLoan hl = new HomeLoan();    //creating an object for HomeLoan class
					     System.out.println("Enter the principle amount in Rs ");
					     double hlamount = sc.nextDouble();
					     try 
					     {
					     System.out.println("Interest amount is : Rs " + hl.calculateInterest(hlamount));
					     }catch (InvalidAmountException e)
					     {
			                    System.out.println("Exception : Invalid amount!");
			                }
                         break;
                    case 3:
                    	 GoldLoan gl = new GoldLoan();     //creating an object for GoldLoan class
					     System.out.println("Enter the principle amount  in Rs");
					     double glamount = sc.nextDouble();
					     try 
					     {
					     System.out.println("Interest amount is : Rs " + gl.calculateInterest(glamount));
					     }catch (InvalidAmountException e) 
					     {
			                    System.out.println("Exception : Invalid amount!");
			                }
                         break;
                    case 4:
                   	     AgriLoan ag = new AgriLoan();    //creating an object for AgriLoan class
					     System.out.println("Enter the principle amount in Rs ");
					     double agamount = sc.nextDouble();
					     try 
					     {					     
					     System.out.println("Interest amount is : Rs " + ag.calculateInterest(agamount));
					     }catch (InvalidAmountException e)
					     {
			                    System.out.println("Exception : Invalid amount!");
			                }
                         break;
                    case 5:
                  	     BusinessLoan bl = new BusinessLoan();      //creating an object for BusinessLoan class
					     System.out.println("Enter the principle amount in Rs ");
					     double blamount = sc.nextDouble();				
					     System.out.println("Interest amount is : Rs " + bl.calculateInterest(blamount));
					     break;
                    
                    case 6:
                    	
                    	displayHistory();
                 	     break;
                 	     
                   case 7:
                    	
                    	resetHistory();
                 	     break;
                 	     
                    case 8:
                    	
                 	   System.out.println("Thank you for using Interest Amount Calculator !!!");
                 	   System.exit(0);   
                 	   
                   
                    	
                     default:
                        System.out.println("Wrong choice");
                    	 break; 
                      
                      }
        case 3:
        	   displayHistory();
        	   break;
        	   
        case 4:
        		   
        	   resetHistory();
        	   break;
        	   
        case 5:
        	  
        	   System.out.println("Thank you for using Interest Amount Calculator !!!");
        	   System.exit(0);  
           
        default:
                break;
             }
        }catch (InvalidYearsException e)
        {
            System.out.println("Exception : Invalid years!");
        }
       }while(true);
}

		private void displayHistory() {
			File file = new File("C:\\Users\\241352\\Java-Workspace\\Project\\output1.txt");

			if (file.length() == 0) {
			System.out.println("File is empty");
			} else {
			try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = br.readLine()) != null) {
			System.out.println(line);
			}
			} catch (IOException e) {
			e.printStackTrace();
			}
		}
}

		private void resetHistory() {
			 File file = new File("C:\\Users\\241352\\Java-Workspace\\Project\\output1.txt");

		        try (FileWriter fileWriter = new FileWriter(file, false)) {
		            fileWriter.write("");
		            System.out.println("Contents of file \"" + file.getName() + "\" deleted successfully.");
		        } catch (IOException e) {
		            System.out.println("An error occurred while deleting contents of file \"" + file.getName() + "\".");
		            e.printStackTrace();
		        }
		    }
 }
