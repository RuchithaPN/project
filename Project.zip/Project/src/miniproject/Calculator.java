package miniproject;

public interface Calculator {
	double calculateInterest(double amount) throws InvalidAmountException;

}
