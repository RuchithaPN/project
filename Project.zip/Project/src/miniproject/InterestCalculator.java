package miniproject;

import java.io.IOException;

public class InterestCalculator {

	public static void main(String[] args) throws InvalidYearsException, InvalidAmountException {
		InterestAmountCalculator obj=new InterestAmountCalculator();
        obj.Interest();
	}

}
