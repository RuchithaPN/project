package miniproject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

class SimpleInterest implements Calculator{
	 double siAmount;
	 double noOfYears;
	 double rateOfInterest;
	 
	 Scanner scanner = new Scanner(System.in);

	
	public double calculateInterest(double amount) throws InvalidAmountException {
		 this.siAmount = amount;
		 if(siAmount <= 0 ){
	            throw new InvalidAmountException();
	        }
		 System.out.println("Enter rate of interest");
		 rateOfInterest = scanner.nextDouble();
		 System.out.println("Enter number of years");
	     noOfYears = scanner.nextDouble();
	     
	     double interestAmount= (amount* rateOfInterest* noOfYears)/100;	
	     
	       DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        Date date = new Date();
	        String dateTime = dateFormat.format(date);
	        File file = new File("C:\\Users\\241352\\Java-Workspace\\Project\\output1.txt");

	        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
	        	writer.println("Generated date and time:" +dateTime);
	        	writer.println("------------------------------");
	            writer.println("Simple Interest");
	            writer.println("-------------------------------"); 
	            writer.write("Simple interest is " + interestAmount);
	            writer.println();
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file");
	            e.printStackTrace();
	        }

	        return interestAmount;
	}
}
